import numpy as np
import torch
import PIL


class Masker():
    """Object for masking and demasking"""

    def __init__(self, width=3, mode='interpolate', infer_single_pass=False, include_mask_as_input=False):
        self.grid_size = width # 4
        self.n_masks = width ** 2 # 마스크 갯수 16개

        self.mode = mode
        self.infer_single_pass = infer_single_pass
        self.include_mask_as_input = include_mask_as_input

    def mask(self, X, i): #input, epochID 

        phasex = i % self.grid_size #0, 1, 2, 3, 0, 1, 2, 3 ..
        phasey = (i // self.grid_size) % self.grid_size
        mask = pixel_grid_mask(X[0, 0].shape, self.grid_size, phasex, phasey)  # J is chosen randomly for each batch
        mask = mask.to(X.device)

        mask_inv = torch.ones(mask.shape).to(X.device) - mask # valid : 1, unvalid : 0

        if self.mode == 'interpolate':
            masked = interpolate_mask(X, mask, mask_inv)
        elif self.mode == 'zero':
            masked = X * mask_inv
        else:
            raise NotImplementedError
            
        if self.include_mask_as_input:
            net_input = torch.cat((masked, mask.repeat(X.shape[0], 1, 1, 1)), dim=1)
        else:
            net_input = masked

        return net_input, mask

    def __len__(self):
        return self.n_masks

    def infer_full_image(self, X, model):

        if self.infer_single_pass:
            if self.include_mask_as_input:
                net_input = torch.cat((X, torch.zeros(X[:, 0:1].shape).to(X.device)), dim=1)
            else:
                net_input = X
            net_output = model(net_input)
            return net_output

        else:
            net_input, mask = self.mask(X, 0)
            net_output = model(net_input)

            acc_tensor = torch.zeros(net_output.shape).cpu()

            for i in range(self.n_masks):
                net_input, mask = self.mask(X, i)
                net_output = model(net_input)
                acc_tensor = acc_tensor + (net_output * mask).cpu()

            return acc_tensor


def pixel_grid_mask(shape, patch_size, phase_x, phase_y): # 512 * 512
    A = torch.zeros(shape[-2:])
    for i in range(shape[-2]):
        for j in range(shape[-1]):
            if (i % patch_size == phase_x and j % patch_size == phase_y):
                A[i, j] = 1
    return torch.Tensor(A)


def interpolate_mask(tensor, mask, mask_inv):
    device = tensor.device
    mask = mask.to(device) #grid mask
    
    #kernel = np.array([(0.5, 1.0, 0.5), (1.0, 0.0, 1.0), (0.5, 1.0, 0.5)])
    #kernel = np.array([(0, 0.25, 0), (0.25, 0, 0.25), (0, 0.25, 0)]) #original kernel
    kernel = np.array([[[0, 0.5, 0], [0.5, 1.0, 0.5], [0, 0.5, 0]],
                                [[0.5, 1.0, 0.5], [1.0, 0.0, 1.0], [0.5, 1.0, 0.5]],
                                [[0, 0.5, 0], [0.5, 1.0, 0.5], [0, 0.5, 0]]])

    kernel = kernel[np.newaxis, :, :, :]  # (1,1,3,3) -> (1,3,3,3)
    #kernel = kernel[np.newaxis, np.newaxis, :, :]  # (1,1,3,3)
   
    kernel = torch.Tensor(kernel).to(device)
    kernel = kernel / kernel.sum()

    filtered_tensor = torch.nn.functional.conv2d(tensor, kernel, stride=1, padding=1) #(16, 1, 512, 512)
    #print(filtered_tensor.shape)
    return filtered_tensor * mask + tensor * mask_inv 
