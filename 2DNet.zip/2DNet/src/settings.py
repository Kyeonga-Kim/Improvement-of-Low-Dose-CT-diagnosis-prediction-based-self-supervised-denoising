train_png_dir = r'/home/dataset/RSNA/stage2_train_png/'
test_png_dir = r'/home/dataset/RSNA/stage2_test_png/'
img_path = r'/home/dataset/RSNA/rsna-intracranial-hemorrhage-detection/stage_2_train/'